#using <mscorlib.dll>
[assembly: System::Runtime::Versioning::TargetFrameworkAttribute(L".NETFramework,Version=v4.7.2", FrameworkDisplayName=L".NET Framework 4.7.2")];
